#include "main.h"
int option;
int display(ab *a){
    printf("1.Creat Contact \n2.Search Contact \n3.Edit Contact \n4.Delete contact \n5.list contact \n6.Save and Exit\n\n");
    printf("Choose the Option : ");
    scanf("%d",&option);
    switch(option)
    {
        case 1:
        printf("Creat contact :\n");
        creatcontact(a);
        break;
        case 2:
        printf("Search contact : \n");
        searchcontact(a);
        break;
        case 3:
        printf("Edit contact : \n");
        editcontact(a);
        break;
        case 4:
        printf("Delete contact : \n");
        deletecontact(a);
        break;
        case 5:
        printf("list contact : \n");
        listcontact(a);
        break;
        case 6:
        printf("Save and Exit : \n");
        save_exit(a);
        break;
        default :
        getchar();
        printf("Thank you @\n");
        break;
    }

}
int main(){
    printf("\n");
    printf("Welcome to Address_Book : \n\n");
    ab a[100];
    loadcontact(a);
    do
    {
        
       display(a);

    }while(option<6);

    return 0;
}