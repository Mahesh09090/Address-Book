#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
typedef struct address_book
{
    char name[20];
    char mobile_no[11];
    char mailid[30];
    int sn;
}ab;
void loadcontact(ab *a);
void creatcontact(ab *a);
void searchcontact(ab *a);
void editcontact(ab *a);
void deletecontact(ab *a);
void listcontact(ab *a);
void save_exit(ab *a);
